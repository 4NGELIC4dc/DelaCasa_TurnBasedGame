package com.example.delacasa_myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class secondPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);
    }
}